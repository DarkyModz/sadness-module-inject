package com.sadness;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Build.VERSION;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import java.io.File;
import android.app.Activity;
import android.content.Context;
import android.content.ActivityNotFoundException;
import android.os.Process;
import android.widget.Toast;
import android.app.ActivityManager;
import android.os.Handler;

public class MainActivity extends Activity {

    private static final int CODE_DRAW_OVER_OTHER_APP_PERMISSION = 111;

    @SuppressLint("WrongThread")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

		Intent launch = this.getPackageManager().getLaunchIntentForPackage("com.dts.freefireth"); 
		if (launch != null) {
			
	    this.startActivity(launch);
	
		Start(this);
        Init(this);
		
		LimpaConta();
        }
    }
	
	public static void deleteFile(String path) {
        File file = new File(path);
        if (!file.exists()) return;
        if (file.isFile()) {
            file.delete();
            return;
        }
        File[] fileArr = file.listFiles();
        if (fileArr != null) {
            for (File subFile : fileArr) {
                if (subFile.isDirectory()) {
                    deleteFile(subFile.getAbsolutePath());
                }
                if (subFile.isFile()) {
                    subFile.delete();
                }
            }
        }
        file.delete();
    }
	
	private void Init(final Context ctx) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(ctx)) {
 
        ctx.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + ctx.getPackageName())));
		
		final Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                System.exit(1);
                }
            }, 5000);
	    	return;
	        } else {
	  	    final Handler handler = new Handler();
		    handler.postDelayed(new Runnable() {
				
            @Override
            public void run() {
					
            ctx.startService(new Intent(ctx, FloatingModMenuService.class));
			
            }
            }, 500);
	     }
	 }
 
	private void LimpaConta() {
		
		deleteFile("/sdcard/Android/data/com.dts.freefireth/files/reportnew.db");
		deleteFile("/sdcard/Android/data/com.dts.freefireth/files/ymrtc_log.txt");
		deleteFile("/sdcard/Android/data/com.dts.freefireth/cache");
		deleteFile("/data/user/0/com.dts.freefireth/files/__tsecache.dat");
		deleteFile("/data/user/0/com.dts.freefireth/files/cache.crc.dat");
	}
	 
	public static void Start(Context paramContext) {
        if (VERSION.SDK_INT < 23 || Settings.canDrawOverlays(paramContext)) {
            if (paramContext.checkCallingOrSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                if (paramContext.checkCallingOrSelfPermission("android.permission.READ_PHONE_STATE") == 0) {
                    return;
                }
            }
            showInstalledAppDetails(paramContext, paramContext.getPackageName());
            Process.killProcess(Process.myPid());
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("package:");
        stringBuilder.append(paramContext.getPackageName());
        paramContext.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse(stringBuilder.toString())));
        Process.killProcess(Process.myPid());
    }
	
	private static void showInstalledAppDetails(Context context, String packageName) {
        try {
            Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("package:");
            stringBuilder.append(packageName);
            intent.setData(Uri.parse(stringBuilder.toString()));
            context.startActivity(intent);
			
        } catch (ActivityNotFoundException e) {
			
        context.startActivity(new Intent("android.settings.MANAGE_APPLICATIONS_SETTINGS"));
        }
    }
}
