package com.sadness;

import android.content.Context;
import java.io.IOException;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class Bruno implements IXposedHookLoadPackage {
	
    public static final String TAG = "sadness";

    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
		
    if (lpparam.packageName.equals("com.dts.freefireth")) {
		
    StringBuilder stringBuilder = new StringBuilder();
	stringBuilder.append("sadness ");
    stringBuilder.append(lpparam.packageName);
    XposedBridge.log(stringBuilder.toString());
	
    try {
				
	System.load("/data/local/tmp/libsadness.so");
			
	XposedBridge.log("sadness lib carregada");
		
    } catch (Exception e) {
				
    e.printStackTrace();
    }
    }
    }
}
