package com.sadness;

import android.app.AlertDialog;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.util.TypedValue;
import android.view.Display.Mode;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import android.text.Html;
import android.os.Handler;
import android.app.AlertDialog.Builder;
import android.os.Build.VERSION;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.util.Log;
import eu.chainfire.libsuperuser.Shell;
import android.annotation.SuppressLint;
import android.content.res.AssetManager;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import android.widget.Switch;
import android.media.MediaPlayer;
import android.graphics.drawable.Drawable;
import android.view.ViewGroup;
import android.icu.util.Calendar;
import android.view.Gravity;
import android.widget.FrameLayout.LayoutParams;

/* renamed from: bruno.xposedmodule.FloatingModMenuService */
public class FloatingModMenuService extends Service {
    
	
	
	private MediaPlayer FXPlayer;
    public View mFloatingView;
	//private Button EspFire;
	private ImageView closeimage;
	private ImageView ffid;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private ImageView startimage2;
    private LinearLayout view1;
    private LinearLayout view2;
	private Button Injetar;
    private Button Close;

    //initialize methods from the native library
    public static native String Toast();

  /*  com.ness.Prefs prefs;
	//Prefs prefs;
    public String Validade = com.ness.Prefs.with(this).read("VAL");
	public String Validade2 = com.ness.Prefs.with(this).read("Validade");
	public String RegisterDate = com.ness.Prefs.with(this).read("RegisterDate");
	public String Versao = com.ness.Prefs.with(this).read("Version");
	public String Devices = com.ness.Prefs.with(this).read("Devices");
	public String Vendedor = com.ness.Prefs.with(this).read("vendedor");
	public String Acesso = com.ness.Prefs.with(this).read("Acesso");
	public String Usuario = com.ness.Prefs.with(this).read("USER");
	public String Mod = com.ness.Prefs.with(this).read("Mod");
    public String Uid = com.ness.Prefs.with(this).read("UID");
    public String Senha = com.ness.Prefs.with(this).read("PASS");
*/

	private int IconSize() {
		return 55;
	}

    private int IconSize2() {
        return 40;
	}
	
    public IBinder onBind(Intent intent) {
    return null;
    }
	
	public static String ColorAll() {

	return "#00CCCC";
	}

	public static void deleteFile(String path) {
        File file = new File(path);
        if (!file.exists()) return;
        if (file.isFile()) {
            file.delete();
            return;
        }
        File[] fileArr = file.listFiles();
        if (fileArr != null) {
            for (File subFile : fileArr) {
                if (subFile.isDirectory()) {
                    deleteFile(subFile.getAbsolutePath());
                }
                if (subFile.isFile()) {
                    subFile.delete();
                }
            }
        }
        file.delete();
    }
	
	private static RandomAccessFile Verylaser;
	private static RandomAccessFile raf;

	private native String[] BrunoModsFeature();
	

	public void onCreate() {
        super.onCreate();
		
		Running();
		initFloating();
		
		boolean libError = false;
		
		try {

			String payload_source = this.getApplicationInfo().nativeLibraryDir + File.separator + "libsadness.so";

			String payload_dest = "/data/local/tmp/libsadness.so";

			Shell.Pool.SU.run(new String[] {"cp " + payload_source + " " + payload_dest, "chmod 777 " + payload_dest});

		} catch (Shell.ShellDiedException e) {

			Toast.makeText(this, "Falha ao iniciar", 0).show();

			libError = true;

		}
    }
	
	static {
		System.loadLibrary("sadness");
    }
	
	
	private void Running() {
		final Handler handler = new Handler();
        handler.post(new Runnable() {
				public void run() {
					Thread();
					handler.postDelayed(this, 1000);
				}
			}
		);
	}
	
    private void initFloating() {
		rootFrame = new FrameLayout(getBaseContext()); // Global markup
        mRootContainer = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(getBaseContext()); // Markup of the icon (when the menu is minimized)
        mExpanded = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        view1 = new LinearLayout(getBaseContext());
        patches = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
		AssetManager assetManager = getAssets();
        mButtonPanel = new LinearLayout(getBaseContext());

		//---------- Gradiente ----------\\

        //Injetor
        android.graphics.drawable.GradientDrawable Background_Principal = new android.graphics.drawable.GradientDrawable();
        Background_Principal.setStroke(2, Color.parseColor("#ff0000"));
        Background_Principal.setColor(Color.parseColor("#000000"));
        Background_Principal.setCornerRadius(3);

        //HIDE
        android.graphics.drawable.GradientDrawable Background_HIDE = new android.graphics.drawable.GradientDrawable();
        Background_HIDE.setCornerRadius(4);
        Background_HIDE.setStroke(2, Color.parseColor("#ffffff"));
        Background_HIDE.setColor(Color.parseColor("#00000000"));

		//CLOSE
        android.graphics.drawable.GradientDrawable Background_CLOSE = new android.graphics.drawable.GradientDrawable();
        Background_CLOSE.setCornerRadius(4);
        Background_CLOSE.setStroke(2, Color.parseColor("#ffffff"));
        Background_CLOSE.setColor(Color.parseColor("#00000000"));

		//---------- Buttons Close - Hide ----------\\

		//Relative
        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setVerticalGravity(16);

        //CLOSE
        this.Close = new Button(this);
        this.Close.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(33)));
        this.Close.setTextSize(2, 10.0f);
        this.Close.setTypeface((Typeface) null, 1);
        this.Close.setBackgroundColor(Color.parseColor("#ff0000"));
        this.Close.setTextColor(-1);
        this.Close.setText("CLOSE");

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, dp(33));
        layoutParams.addRule(11);

        //HIDE
        this.Injetar = new Button(this);
        this.Injetar.setLayoutParams(layoutParams);
        this.Injetar.setTextSize(2, 10.0f);
        this.Injetar.setTypeface((Typeface) null, 1);
        this.Injetar.setBackgroundColor(Color.parseColor("#00000000"));
        this.Injetar.setTextColor(Color.parseColor("#00000000"));
        this.Injetar.setText("");

        //Collapse
        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);

		//---------- ImageView ----------\\

		//Logo
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        InputStream inputStream_icon = null;
        try {
            inputStream_icon = assetManager.open("ic_sadness.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable icon = Drawable.createFromStream(inputStream_icon, null);
        startimage.setImageDrawable(icon);
		startimage.setImageDrawable(icon);
		((ViewGroup.MarginLayoutParams) this.startimage.getLayoutParams()).leftMargin = convertDipToPixels(0);

        startimage2 = new ImageView(getBaseContext());
        startimage2.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension2 = (int) TypedValue.applyDimension(1, (float) IconSize2(), getResources().getDisplayMetrics());
        startimage2.getLayoutParams().height = applyDimension2;
        startimage2.getLayoutParams().width = applyDimension2;
        startimage2.requestLayout();
        startimage2.setScaleType(ImageView.ScaleType.FIT_XY);
        InputStream inputStream_icon2 = null;
        try {
            inputStream_icon2 = assetManager.open("ic_sadness.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable icon2 = Drawable.createFromStream(inputStream_icon2, null);
        startimage2.setImageDrawable(icon2);
        startimage2.setImageDrawable(icon2);
        ((ViewGroup.MarginLayoutParams) this.startimage2.getLayoutParams()).leftMargin = convertDipToPixels(0);

		//---------- Layout Do Injetor ----------\\

        //mExpanded
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(200), -2));
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        mExpanded.setBackgroundColor(Color.parseColor("#000000"));
        mExpanded.setAlpha(0.9f);
        mExpanded.setVisibility(View.GONE);
        mExpanded.setGravity(17);

        //ScrollView
        ScrollView scrollView = new ScrollView(getBaseContext());
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(148)));

        //View1
        view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 3));
        view1.setBackgroundColor(Color.parseColor("#00000000"));

        //Patches
        patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches.setOrientation(LinearLayout.VERTICAL);

        //View2
        view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 3));
        view2.setBackgroundColor(Color.parseColor("#00000000"));

        //Painel
        mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

        //ModMenu Name
        /*TextView NessText = new TextView(getBaseContext());
		 NessText.setTextColor(Color.parseColor("#ffffff"));
		 NessText.setTypeface(Typeface.MONOSPACE, 1);
		 NessText.setGravity(Gravity.CENTER);
		 NessText.setPadding(10, 13, 10, 0);
		 NessText.setTextSize(18.0f);
		 NessText.setText("SADNESS");*/

        LinearLayout titleText = new LinearLayout(getBaseContext());
        titleText.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        titleText.setOrientation(0);
        titleText.setPadding(dp(8), dp(8), dp(8), dp(8));

        int n2 = Calendar.getInstance().get(11);
        TextView NessText = new TextView(this.getBaseContext());
        if (n2 > 6 && n2 < 12) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SADNESS, Bom Dia");
            NessText.setText((CharSequence)stringBuilder.toString());
        } else if (n2 > 12 && n2 < 18) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SADNESS, Boa Tarde");
            NessText.setText((CharSequence)stringBuilder.toString());
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SADNESS, Boa Noite");
            NessText.setText((CharSequence)stringBuilder.toString());
        }
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams5.gravity = 17;
        layoutParams5.leftMargin = dp(10);
        NessText.setLayoutParams(layoutParams5);
        NessText.setTextColor(Color.parseColor("#ff0000"));
        //NessText.setTypeface(Typeface.DEFAULT_BOLD);
        Typeface GTA = Typeface.createFromAsset(getAssets(), "fonts/pricedow.ttf");
        NessText.setTypeface(GTA);
        NessText.setTextSize(20.0f);

        //O U S 4 D O   B R A B O   N O   J A V A   F D S

        //Validade
        TextView nomeJogoVersao = new TextView(getBaseContext());
        LinearLayout.LayoutParams nomeJogoVersao_Params = new LinearLayout.LayoutParams(-2, -2);
        nomeJogoVersao_Params.gravity = 17;
        nomeJogoVersao_Params.topMargin = dp(12);
        nomeJogoVersao_Params.bottomMargin = dp(12);
        nomeJogoVersao.setLayoutParams(nomeJogoVersao_Params);
       // nomeJogoVersao.setText("Usuário: " + Usuario + "\n" + "Validade: " + Auth.Validade);
        nomeJogoVersao.setTypeface(Typeface.MONOSPACE, 1);
        nomeJogoVersao.setGravity(Gravity.CENTER);
        nomeJogoVersao.setTextSize(10.0f);
        nomeJogoVersao.setTextColor(Color.parseColor("#ffffff"));

		//---------- Parametros ----------\\
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;

		LinearLayout.LayoutParams btns_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(33));
		btns_params.topMargin = dp(5);
        btns_params.leftMargin = dp(5);
        btns_params.rightMargin = dp(5);

		LinearLayout.LayoutParams btns_params2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(33));
		btns_params2.topMargin = dp(-12);
        btns_params2.leftMargin = dp(-6);
        btns_params2.rightMargin = dp(7);
		btns_params2.bottomMargin = dp(-2);
		//btns_params.gravity ="center";

		LinearLayout.LayoutParams btns_params3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(33));
		btns_params3.topMargin = dp(-15);
        btns_params3.leftMargin = dp(-6);
        btns_params3.rightMargin = dp(7);
		btns_params3.bottomMargin = dp(-2);

		//---------- Category Funções ----------\\

		LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.gravity = 17;
        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);

		//---------- Buttons Funções ----------\\

        final Button Aimlock = new Button(this);
        LinearLayout.LayoutParams AimParams = new LinearLayout.LayoutParams(-1, dp(35));
        AimParams.setMargins(5, 3, 5, 2);
        Aimlock.setLayoutParams(AimParams);
        Aimlock.setTextSize(2, 10.0f);
        Aimlock.setTextColor(-1);
        Aimlock.setGravity(17);
        Aimlock.setBackground(NessLayout.botoes(this));
        Aimlock.setTypeface((Typeface) null, 1);
        Aimlock.setText("AIMLOCK");
        Aimlock.setOnClickListener(new View.OnClickListener() {
                private boolean isActive = true;
                @Override
                public void onClick(View v) {
                    if (isActive){

                        writeMod("set_AimLock");
                        Aimlock.setBackground(NessLayout.botoes2(getBaseContext()));
                        isActive = false;
                    }
                    else {
                        writeMod("get_AimLock");
                        Aimlock.setBackground(NessLayout.botoes(getBaseContext()));
                        isActive = true;
                    }
                }
			});

        final Button Ghost = new Button(this);
        LinearLayout.LayoutParams GhostParams = new LinearLayout.LayoutParams(-1, dp(35));
        GhostParams.setMargins(5, 3, 5, 2);
        Ghost.setLayoutParams(GhostParams);
        Ghost.setTextSize(2, 10.0f);
        Ghost.setTextColor(-1);
        Ghost.setGravity(17);
        Ghost.setBackground(NessLayout.botoes(this));
        Ghost.setTypeface((Typeface) null, 1);
        Ghost.setText("MODO FANTASMA");
        Ghost.setOnClickListener(new View.OnClickListener() {
                private boolean isActive = true;
                @Override
                public void onClick(View v) {
                    if (isActive){

                        writeMod("set_Ghost");
                        Ghost.setBackground(NessLayout.botoes2(getBaseContext()));
                        isActive = false;
                    }
                    else {
                        writeMod("get_Ghost");
                        Ghost.setBackground(NessLayout.botoes(getBaseContext()));
                        isActive = true;
                    }
                }
			});

		final Button Wall = new Button(this);
        LinearLayout.LayoutParams WallParams = new LinearLayout.LayoutParams(-1, dp(35));
        WallParams.setMargins(5, 1, 5, 2);
        Wall.setLayoutParams(WallParams);
        Wall.setTextSize(2, 10.0f);
        Wall.setTextColor(-1);
        Wall.setGravity(17);
        Wall.setBackground(NessLayout.botoes(this));
        Wall.setTypeface((Typeface) null, 1);
        Wall.setText("ZÉ PEDRINHA");
        Wall.setOnClickListener(new View.OnClickListener() {
                private boolean isActive = true;
                @Override
                public void onClick(View v) {
                    if (isActive){

                        writeMod("set_Wall");
                        Wall.setBackground(NessLayout.botoes2(getBaseContext()));
                        isActive = false;
                    }
                    else {
                        writeMod("get_Wall");
                        Wall.setBackground(NessLayout.botoes(getBaseContext()));
                        isActive = true;
                    }
                }
			});

        final Button WallCar = new Button(this);
        LinearLayout.LayoutParams WallParamsCar = new LinearLayout.LayoutParams(-1, dp(35));
        WallParamsCar.setMargins(5, 1, 5, 2);
        WallCar.setLayoutParams(WallParamsCar);
        WallCar.setTextSize(2, 10.0f);
        WallCar.setTextColor(-1);
        WallCar.setGravity(17);
        WallCar.setBackground(NessLayout.botoes(this));
        WallCar.setTypeface((Typeface) null, 1);
        WallCar.setText("ZÉ CARRINHO");
        WallCar.setOnClickListener(new View.OnClickListener() {
                private boolean isActive = true;
                @Override
                public void onClick(View v) {
                    if (isActive){

                        writeMod("set_WCar");
                        WallCar.setBackground(NessLayout.botoes2(getBaseContext()));
                        isActive = false;
                    }
                    else {
                        writeMod("get_WCar");
                        WallCar.setBackground(NessLayout.botoes(getBaseContext()));
                        isActive = true;
                    }
                }
            });

        final Button Under = new Button(this);
        LinearLayout.LayoutParams UnderParams = new LinearLayout.LayoutParams(-1, dp(35));
        UnderParams.setMargins(5, 1, 5, 2);
        Under.setLayoutParams(UnderParams);
        Under.setTextSize(2, 10.0f);
        Under.setTextColor(-1);
        Under.setGravity(17);
        Under.setBackground(NessLayout.botoes(this));
        Under.setTypeface((Typeface) null, 1);
        Under.setText("UNDER CARRO");
        Under.setOnClickListener(new View.OnClickListener() {
                private boolean isActive = true;
                @Override
                public void onClick(View v) {
                    if (isActive){

                        writeMod("set_Under");
                        Under.setBackground(NessLayout.botoes2(getBaseContext()));
                        isActive = false;
                    }
                    else {
                        writeMod("get_Under");
                        Under.setBackground(NessLayout.botoes(getBaseContext()));
                        isActive = true;
                    }
                }
			});

        final Button Tele = new Button(this);
        LinearLayout.LayoutParams TeleParams = new LinearLayout.LayoutParams(-1, dp(35));
        TeleParams.setMargins(5, 1, 5, 2);
        Tele.setLayoutParams(TeleParams);
        Tele.setTextSize(2, 10.0f);
        Tele.setTextColor(-1);
        Tele.setGravity(17);
        Tele.setBackground(NessLayout.botoes(this));
        Tele.setTypeface((Typeface) null, 1);
        Tele.setText("TELE CARRO");
        Tele.setOnClickListener(new View.OnClickListener() {
                private boolean isActive = true;
                @Override
                public void onClick(View v) {
                    if (isActive){

                        writeMod("set_TeleCar");
                        Tele.setBackground(NessLayout.botoes2(getBaseContext()));
                        isActive = false;
                    }
                    else {
                        writeMod("get_TeleCar");
                        Tele.setBackground(NessLayout.botoes(getBaseContext()));
                        isActive = true;
                    }
                }
            });    

        final Button Fly = new Button(this);
        LinearLayout.LayoutParams FlyParams = new LinearLayout.LayoutParams(-1, dp(35));
        FlyParams.setMargins(5, 1, 5, 2);
        Fly.setLayoutParams(FlyParams);
        Fly.setTextSize(2, 10.0f);
        Fly.setTextColor(-1);
        Fly.setGravity(17);
        Fly.setBackground(NessLayout.botoes(this));
        Fly.setTypeface((Typeface) null, 1);
        Fly.setText("CARRO VOADOR");
        Fly.setOnClickListener(new View.OnClickListener() {
                private boolean isActive = true;
                @Override
                public void onClick(View v) {
                    if (isActive){

                        writeMod("set_Fly");
                        Fly.setBackground(NessLayout.botoes2(getBaseContext()));
                        isActive = false;
                    }
                    else {
                        writeMod("get_Fly");
                        Fly.setBackground(NessLayout.botoes(getBaseContext()));
                        isActive = true;
                    }
                }
			});

        final Button Curar = new Button(this);
        LinearLayout.LayoutParams CurarParams = new LinearLayout.LayoutParams(-1, dp(35));
        CurarParams.setMargins(5, 1, 5, 2);
        Curar.setLayoutParams(CurarParams);
        Curar.setTextSize(2, 10.0f);
        Curar.setTextColor(-1);
        Curar.setGravity(17);
        Curar.setBackground(NessLayout.botoes(this));
        Curar.setTypeface((Typeface) null, 1);
        Curar.setText("SALVAR RAPIDO");
        Curar.setOnClickListener(new View.OnClickListener() {
                private boolean isActive = true;
                @Override
                public void onClick(View v) {
                    if (isActive){

                        writeMod("set_Curar");
                        Curar.setBackground(NessLayout.botoes2(getBaseContext()));
                        isActive = false;
                    }
                    else {
                        writeMod("get_Curar");
                        Curar.setBackground(NessLayout.botoes(getBaseContext()));
                        isActive = true;
                    }
                }
			});

        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
		mCollapsed.addView(startimage);

        //Cabeça
        mExpanded.addView(titleText);
        titleText.addView(startimage2);
		titleText.addView(NessText);
		//mExpanded.addView(view1);

        //Corpo
		mExpanded.addView(scrollView);
		scrollView.addView(patches);

		//Funções do corpo
        patches.addView(Aimlock);
        patches.addView(Ghost);
        patches.addView(Wall);
        patches.addView(WallCar);
		patches.addView(Under);
        patches.addView(Tele);
        patches.addView(Fly);
        patches.addView(Curar);

        //Pé
        //mExpanded.addView(view2);
        mExpanded.addView(nomeJogoVersao);
        mExpanded.addView(relativeLayout);
        relativeLayout.addView(Injetar);
        relativeLayout.addView(Close);

		mFloatingView = rootFrame;
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);

        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);


		try {
            raf = new RandomAccessFile("/sdcard/Sad.Ness", "rw");
        } catch (FileNotFoundException e) {
            Toast.makeText(getBaseContext(), "Arquivo do jogo não encontrado abra o jogo primeiro!", Toast.LENGTH_LONG).show();

        }

    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);
                            //playSound(Uri.fromFile(new File(cacheDir + "OpenMenu.ogg")));
                            //Toast.makeText(FloatingModMenuService.this, Html.fromHtml(Toast()), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }



	boolean hide = false;
    //Initialize event handlers for buttons, etc.
    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.GONE);
					view3.setVisibility(View.VISIBLE);
				}
			});

		/*Hide.setOnClickListener(new View.OnClickListener() {
		 public void onClick(View view) {
		 //FloatingModMenuService.stopSelf();
		 view2.setVisibility(View.VISIBLE);
		 //view2.setVisibility(View.VISIBLE);
		 view2.setAlpha(0);
		 view3.setVisibility(View.GONE);
		 Toast.makeText(Hide.getContext(), "Ícone Oculto Lembre - Se Da Posiçao Que O Deixou!", Toast.LENGTH_LONG).show();
		 }
		 });*/

		Close.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.VISIBLE);
					view2.setAlpha(0.9f);
					view3.setVisibility(View.GONE);

				}
			});

	}


    private final void addLinear(int i) {
        LinearLayout ln = new LinearLayout(this);
        ln.setLayoutParams(new LayoutParams(-1, i));
        ln.setBackgroundColor(Color.parseColor("#ff0000"));
        patches.addView(ln);
    }

    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();

        if (view2 != null) {
            this.mWindowManager.removeView(view2);
        }
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }

    // checking if any network connection / internet available

    // calling our AsyncTask Function that will do thee thing on fetching data from out host file

    // this is the checking one, this will draw our menu if it's license still valid or active

    //Check if we are still in the game. If now our Menu and Menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life
    public void onTaskRemoved(Intent intent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }

    /* access modifiers changed from: private */
    public void Thread() {
        if (mFloatingView == null) {
            return;
        }

    }

    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }

	private void writeMod(String hex) {
        try {
            raf.seek(0);
            raf.write(hex.getBytes());
            Log.i("SadNess", "writeMod: "+ raf.readUTF());
        } catch (IOException paramString1) {
            paramString1.printStackTrace();
        }
    }
}



