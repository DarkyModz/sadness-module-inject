#include <pthread.h>
#include <jni.h>
#include <stdio.h>
#include <wchar.h>
#include <src/Substrate/SubstrateHook.h>
#include "src/KittyMemory/MemoryPatch.h"
#include "src/Includes/Logger.h"
#include "src/Includes/obfuscator.hpp"
#include "src/memory/Memory.h"
#include "src/brunomods.h"

# define getRealOffset(offset) AgetAbsoluteAddress("libil2cpp.so", offset)

# define HOOK(offset, ptr, orig) MSHookFunction((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)
                                
using namespace std;

struct Patch {

  MemoryPatch WallHack;
  MemoryPatch Underground;
  MemoryPatch TeleCar;
  MemoryPatch FlyCarro;
  MemoryPatch WallCar1;
  MemoryPatch WallCar2;
  MemoryPatch SalvarRapido;
  MemoryPatch AimLockOn;
  MemoryPatch AimLockOff;
  MemoryPatch NoElimine;
  
} Patches;


using namespace std;

struct CheatsParser {
    int    num;
    string str;
    double flt;
};

int stop = 0;
bool start = true;
bool Ghost = false;

void *InjetorBTN(void *) {

    if (strstr(getprogname(), "com.vphonegaga.titan:x")) {
        return nullptr;
    }

    if (strstr(getprogname(), "com.vphonegaga.titan:logcat")) {
        return nullptr;
    }

    if (strcmp(getprogname(), "com.vphonegaga.titan") == 0) {
        return nullptr;
    }

    /* LOGI("logado com sucesso na lib"); */
	
	bool Brzn1 = false;
    bool Brzn2 = false;
    bool Brzn3 = false;
    bool Brzn4 = false;
    bool Brzn5 = false;
    bool Brzn6 = false;
    bool Brzn7 = false;
    bool Brzn8 = false;
    bool Brzn9 = false;
    
    while (1) {

	if (stop > 0) {

	return nullptr;

    }

    FILE *brunoFile = nullptr;
    char FileName[11];

    brunoFile = fopen("/sdcard/Sad.Ness", "r");

	if (brunoFile == NULL) continue;

    while (fgets(FileName, sizeof(FileName), brunoFile) != nullptr) {


	/*----- Start -----*/

	 //AIM::LOCK
     if (strstr(FileName, "get_AimLock")) {
     Patches.AimLockOn.Modify();
     Patches.NoElimine.Modify();
     break;
     }
     if (strstr(FileName, "set_AimLock")) {
     Patches.AimLockOff.Restore();
     break;
     }    
	 //GHOST::HACK
     if (strstr(FileName, "get_Ghost")) {
     Ghost = false;
	 break;
     }
     if (strstr(FileName, "set_Ghost")) {
	 Ghost = true;
	 break;
     }
     //WALL::HACK
     if (strstr(FileName, "get_Wall")) {
     Patches.WallHack.Restore();
     break;
     } 
     if (strstr(FileName, "set_Wall")) {
     Patches.WallHack.Modify();
     break;
     }
     //WALL::CAR
     if (strstr(FileName, "get_WCar")) {
     Patches.WallCar1.Restore();
     Patches.WallCar2.Restore();
     break;
     } 
     if (strstr(FileName, "set_WCar")) {
     Patches.WallCar1.Modify();
     Patches.WallCar2.Modify();
     break;
     }
     //UNDER::CAR
     if (strstr(FileName, "get_Under")) {
     Patches.Underground.Restore();
     break;
     } 
     if (strstr(FileName, "set_Under")) {
     Patches.Underground.Modify();
     break;
     }
     //TELE::CAR
     if (strstr(FileName, "get_TeleCar")) {
     Patches.TeleCar.Restore();
     break;
     } 
     if (strstr(FileName, "set_TeleCar")) {
     Patches.TeleCar.Modify();
     break;
     }
     //FLY::CAR
     if (strstr(FileName, "get_Fly")) {
     Patches.FlyCarro.Restore();
     break;
     } 
     if (strstr(FileName, "set_Fly")) {
     Patches.FlyCarro.Modify();
     break;
     }
     //SALVAR::RAPIDO
     if (strstr(FileName, "get_Curar")) {
     Patches.SalvarRapido.Restore();
     break;
     } 
     if (strstr(FileName, "set_Curar")) {
     Patches.SalvarRapido.Modify();
     break;
     }
	
    }
    sleep(1);
    }
    return nullptr;
}

bool (*GhostV2)(void* _Updatex, int Value);
bool _GhostV2(void* _Updatex, int Value) {
    if (_Updatex != nullptr) {
    if (Ghost) {
       return false;
    }
    }
    return GhostV2(_Updatex, Value);
}

void *OffsetAdress(void *) {
	
    while (true) {
		
    if (getRealOffset(0) != 0) {
	
	/*--- adress ---*/
    MSHookFunction((void *)getRealOffset(0xE0A34C), (void *)&_GhostV2, (void **)&GhostV2);//private bool EGfvuBd(Player KE`SW[H) { }
	
    Patches.FlyCarro = MemoryPatch("libil2cpp.so", 0x22B6DD8, "\x00\x00\xB8\x41", 4);

    Patches.Underground = MemoryPatch("libil2cpp.so", 0x22B6DD8, "\x00\x00\x00\xC0", 4);

    Patches.WallHack = MemoryPatch("libunity.so", 0xAD7E68, "\x00\x00\x00\x00", 4);

    Patches.WallCar1 = MemoryPatch("libil2cpp.so", 0x20DD898, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8); 
 
    Patches.WallCar2 = MemoryPatch("libil2cpp.so", 0x20DC474, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
    
    Patches.TeleCar = MemoryPatch("libil2cpp.so", 0x22B6C44, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
    
    Patches.SalvarRapido = MemoryPatch("libil2cpp.so", 0xCCFFB2, "\x10\x00\x00\x00", 4);
    
    Patches.AimLockOn = MemoryPatch::createWithHex("libil2cpp.so", 0xFC7F2C, "01 00 A0 E3 1E FF 2F E1");
 
    Patches.AimLockOff = MemoryPatch::createWithHex("libil2cpp.so", 0xFC7F2C, "10 4C 2D E9 08 B0 8D E2");

    Patches.NoElimine = MemoryPatch::createWithHex("libil2cpp.so", 0x9382FC, "00 00 A0 E3 1E FF 2F E1");
    
    
    pthread_exit(nullptr);
    }
	sleep(1);
    }
    return nullptr;
}

extern "C" 
void __attribute__ ((constructor)) Get_IsStart() {
	
	pthread_t ptid1;
	pthread_create(&ptid1, nullptr, OffsetAdress, nullptr);

}

void __attribute__ ((constructor)) Get_IsFeatureBTN() {
	
   FILE *brunoFile = nullptr;
   
   brunoFile = fopen("/sdcard/Sad.Ness", "r");
   
   if (brunoFile == nullptr) fopen("/sdcard/Sad.Ness", "w+");

   pthread_t ptid2;
   pthread_create(&ptid2, nullptr, InjetorBTN, nullptr);

}
