#ifndef ANDROID_MOD_MENU_brunomods_H
#define ANDROID_MOD_MENU_brunomods_H

#include <sys/syscall.h>
using namespace std;
#include <string>
#include <sstream>
#include <iostream>
#include <sstream>

long AfindLibrary(const char *library) {
	
    char filename[0xFF] = {0},
    buffer[1024] = {0};
    FILE *fp = NULL;
    long address = 0;

    sprintf(filename, "/proc/self/maps");

    fp = fopen(filename, "rt");
    if(fp == NULL) {
    perror("fopen");
    goto done;
    }

    while(fgets(buffer, sizeof(buffer), fp)) {
    if (strstr(buffer, library)) {
    address = (long)strtoul(buffer, NULL, 16);
    goto done;
    }
    }

    done:

    if (fp) {
    fclose(fp);
    }
    return address;
}

long ClibBase;

long AgetAbsoluteAddress(const char* libraryName, long relativeAddr) {
    if (ClibBase == 0) {
        ClibBase = AfindLibrary(libraryName);
    if (ClibBase == 0) {
        ClibBase = 0;
        }
    }
    return ClibBase + relativeAddr;
}

# define getRealOffset(offset) AgetAbsoluteAddress("libil2cpp.so", offset)

#endif

